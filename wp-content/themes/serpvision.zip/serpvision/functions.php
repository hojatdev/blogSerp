<?php

function serpvision_url($key) {
    $urls = [
        'register' => 'https://app.serpvision.com/register',
        'login'    => 'https://app.serpvision.com/login',
        'pricing'  => home_url('/pricing/'),
    ];

    return $urls[$key] ?? home_url('/');
}

function serpvision_enqueue_assets() {
    wp_enqueue_style(
        'serpvision-style',
        get_stylesheet_uri(),
        [],
        '1.0.0'
    );

    wp_enqueue_style(
        'serpvision-main',
        get_template_directory_uri() . '/assets/css/style.css',
        ['serpvision-style'],
        '1.0.0'
    );

    wp_enqueue_script(
        'serpvision-script',
        get_template_directory_uri() . '/assets/js/scripts.js',
        [],
        '1.0.0',
        true
    );
}

add_action('wp_enqueue_scripts', 'serpvision_enqueue_assets');

function serpvision_is_active_path($path) {
    $target_path = trim($path, '/');
    $current_path = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');

    // Home page
    if ($target_path === '') {
        return is_front_page();
    }

    // For now, match Blog only by URL path
    // Later, when you create a real Posts Page, we can improve this.
    return $current_path === $target_path;
}

function serpvision_nav_link_class($path, $variant = 'mobile') {
    if ($variant === 'desktop') {
        $base_class = 'px-3 py-2 text-sm font-medium rounded-lg transition-colors';
    } else {
        $base_class = 'px-3 py-3 text-sm font-medium rounded-lg transition-colors';
    }

    if (serpvision_is_active_path($path)) {
        return $base_class . ' text-indigo-600 bg-indigo-50';
    }

    return $base_class . ' text-slate-600 hover:text-slate-900 hover:bg-slate-50';
}

function serpvision_aria_current($path) {
    return serpvision_is_active_path($path) ? 'aria-current="page"' : '';
}

add_post_type_support('page', 'excerpt');

// ════════════════════════════════════════════════════════════
// Security Hardening
// ════════════════════════════════════════════════════════════

// 1. Remove WordPress version number from <head> and RSS feeds
remove_action('wp_head', 'wp_generator');
add_filter('the_generator', '__return_empty_string');

// 2. Strip ?ver=X.X from script/style URLs (hides WP/plugin versions)
add_filter('style_loader_src',  'serpvision_remove_ver_query', 10, 1);
add_filter('script_loader_src', 'serpvision_remove_ver_query', 10, 1);
function serpvision_remove_ver_query($src) {
    return $src ? remove_query_arg('ver', $src) : $src;
}

// 3. Generic login error — don't reveal whether username or password is wrong
add_filter('login_errors', function() {
    return 'Incorrect credentials. Please try again.';
});

// 4. Disable XML-RPC (primary brute-force & DDoS amplification vector)
add_filter('xmlrpc_enabled', '__return_false');
add_filter('xmlrpc_methods', function($methods) {
    unset($methods['pingback.ping'], $methods['pingback.extensions.getPingbacks']);
    return $methods;
});

// 5. Remove discovery links that expose WP infrastructure
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'wp_shortlink_wp_head');
remove_action('wp_head', 'adjacent_posts_rel_link_wp_head');
remove_action('wp_head', 'feed_links_extra', 3);
remove_action('template_redirect', 'rest_output_link_header', 11);

// 6. Block author enumeration (?author=1 scans reveal usernames)
add_action('template_redirect', function() {
    if ( ! is_admin() && isset($_GET['author']) ) {
        wp_die('Access denied.', 'Forbidden', ['response' => 403]);
    }
});

// 7. Remove /wp/v2/users endpoint from REST API for logged-out visitors
add_filter('rest_endpoints', function($endpoints) {
    if ( ! is_user_logged_in() ) {
        unset(
            $endpoints['/wp/v2/users'],
            $endpoints['/wp/v2/users/(?P<id>[\d]+)']
        );
    }
    return $endpoints;
});

// 8. Send HTTP security headers on every page load
add_action('send_headers', function() {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
});

// 9. Disable automatic pingbacks on new posts
add_filter('pre_option_default_ping_status', '__return_zero');

// ════════════════════════════════════════════════════════════

function serpvision_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('automatic-feed-links');
    add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script']);
}
add_action('after_setup_theme', 'serpvision_theme_setup');
